<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from html.wordpresspie.com/country/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 14 Dec 2018 16:02:11 GMT -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <title>Country - Political HTML5 Template</title>

    <!-- Styles -->
    <link rel="stylesheet" href="{{asset('public/frontend/assets/css/bootstrap.min.css')}}"><!-- Bootstrap -->
    <link rel="stylesheet" href="{{asset('public/frontend/assets/css/webfonts.css')}}"><!-- Font Awesome -->
    <link rel="stylesheet" href="{{asset('public/frontend/assets/css/style.css')}}"><!-- Style -->
    <link rel="stylesheet" href="{{asset('public/frontend/assets/css/responsive.css')}}"><!-- Responsive -->
    <link rel="stylesheet" href="{{asset('public/frontend/assets/css/color.css')}}"><!-- Default Color Scheme -->

    <!-- REVOLUTION STYLE SHEETS -->
    <link rel="stylesheet" href="{{asset('public/frontend/assets/css/revolution/settings.css')}}">
    <!-- REVOLUTION LAYERS STYLES -->
    <link rel="stylesheet" href="{{asset('public/frontend/assets/css/revolution/layers.css')}}">
    <!-- REVOLUTION NAVIGATION STYLES -->
    <link rel="stylesheet" href="{{asset('public/frontend/assets/css/revolution/navigation.css')}}">
</head>
<body itemscope>
<main>
    <header class="style1">
        {{--<div class="notification-box">--}}
            {{--<div class="container">--}}
                {{--<div class="notifecation-message"><strong>GET INCLUDED:</strong> Join The party as we stand for Civil Rights. <a href="#" title="" itemprop="url">Make A Member Today.</a></div>--}}
                {{--<span class="notification-close-btn brd-rd5"><i class="fa fa-close"></i></span>--}}
            {{--</div>--}}
        {{--</div>--}}
        <div class="header-top">
            <div class="container">
                <div class="header-top-inner">
                    <div class="logo"><a href="index-2.html" title="" itemprop="url"><img src="{{asset('public/frontend/assets/images/lg.png')}}" alt="logo.png" itemprop="image"></a></div>
                    <div class="top-links">
                        <a href="#" title=""><i class="fa fa-sign-in theme-clr"></i> Login</a>
                        <a href="#" title=""><i class="fa fa-user theme-clr"></i> Sign Up</a>
                    </div>
                    <a class="brd-rd30 theme-btn theme-bg" href="donate-now.html" title="" itemprop="url">DONATE</a>
                    <div class="top-links">
                        <a href="become-volunteer.html" title="" itemprop="url">BECOME A MEMBER</a>
                        <a href="#" title="" itemprop="url"><i class="fa fa-shopping-basket theme-clr"></i> SHOP</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="menu-wrapper">
            <div class="container">
                <nav class="brd-rd5 theme-bg">
                    <div>
                        <ul>
                            <li class="menu-item-has-children"><a href="#" title="" itemprop="url">HOME</a>
                                <ul>
                                    <li><a href="index-2.html" title="" itemprop="url">Homepage 1</a></li>
                                    <li><a href="index-rtl-arabic.html" title="" itemprop="url">Homepage  RTL (Arabic)</a></li>
                                    <li><a href="index2.html" title="" itemprop="url">Homepage 3</a></li>
                                    <li><a href="index2-boxed.html" title="" itemprop="url">Homepage Boxed</a></li>
                                </ul>
                            </li>
                            <li class="menu-item-has-children"><a href="#" title="" itemprop="url">BLOG</a>
                                <ul>
                                    <li><a href="blog-grid.html" title="" itemprop="url">Blog Grid Style</a></li>
                                    <li><a href="blog-unique.html" title="" itemprop="url">Blog Unique Grid Style</a></li>
                                    <li><a href="blog-list.html" title="" itemprop="url">Blog List Style</a></li>
                                    <li><a href="blog-detail.html" title="" itemprop="url">Blog Detail</a></li>
                                </ul>
                            </li>
                            <li class="menu-item-has-children"><a href="#" title="" itemprop="url">PAGES</a>
                                <ul>
                                    <li class="menu-item-has-children"><a href="#" title="" itemprop="url">Priorities</a>
                                        <ul>
                                            <li><a href="priorities.html" title="" itemprop="url">Our Priorities</a></li>
                                            <li><a href="priorities-detail.html" title="" itemprop="url">Priorities Detail</a></li>
                                        </ul>
                                    </li>
                                    <li class="menu-item-has-children"><a href="#" title="" itemprop="url">Our Volunteers</a>
                                        <ul>
                                            <li><a href="volunteer.html" title="" itemprop="url">Our Volunteers</a></li>
                                            <li><a href="volunteer-detail.html" title="" itemprop="url">Volunteers Detail</a></li>
                                        </ul>
                                    </li>
                                    <li class="menu-item-has-children"><a href="#" title="" itemprop="url">Gallery</a>
                                        <ul>
                                            <li><a href="gallery1.html" title="" itemprop="url">Gallery Style 1</a></li>
                                            <li><a href="gallery2.html" title="" itemprop="url">Gallery Style 2</a></li>
                                            <li><a href="gallery3.html" title="" itemprop="url">Gallery Style 3</a></li>
                                        </ul>
                                    </li>
                                    <li><a href="become-volunteer.html" title="" itemprop="url">Become A Volunteer</a></li>
                                    <li><a href="donate-now.html" title="" itemprop="url">Donate Now</a></li>
                                    <li><a href="mission-vission.html" title="" itemprop="url">Mission & Vission</a></li>
                                    <li><a href="branches.html" title="" itemprop="url">Find Your Local Unit</a></li>
                                    <li><a href="coming-soon.html" title="" itemprop="url">Coming Soon</a></li>
                                    <li><a href="404.html" title="" itemprop="url">404 Error Page</a></li>
                                </ul>
                            </li>
                            <li class="menu-item-has-children"><a href="#" title="" itemprop="url">TAKE ACTION</a>
                                <ul>
                                    <li><a href="causes-grid.html" title="" itemprop="url">Cause Grid Style</a></li>
                                    <li><a href="causes-list.html" title="" itemprop="url">Cause List Style</a></li>
                                    <li><a href="cause-detail.html" title="" itemprop="url">Cause Detail</a></li>
                                </ul>
                            </li>
                            <li class="menu-item-has-children"><a href="#" title="" itemprop="url">SHOP</a>
                                <ul>
                                    <li><a href="products.html" title="" itemprop="url">Our Products</a></li>
                                    <li><a href="product-detail.html" title="" itemprop="url">Product Detail</a></li>
                                    <li><a href="product-cart.html" title="" itemprop="url">Product Cart</a></li>
                                    <li><a href="checkout.html" title="" itemprop="url">Checkout</a></li>
                                </ul>
                            </li>
                            <li class="menu-item-has-children"><a href="#" title="" itemprop="url">OUR EVENTS</a>
                                <ul>
                                    <li><a href="events-grid.html" title="" itemprop="url">Events Grid Style 1</a></li>
                                    <li><a href="events-grid2.html" title="" itemprop="url">Events Grid Style 2</a></li>
                                    <li><a href="events-list.html" title="" itemprop="url">Events List Style</a></li>
                                    <li><a href="event-detail.html" title="" itemprop="url">Event Detail</a></li>
                                </ul>
                            </li>
                            <li><a href="about-us.html" title="" itemprop="url">ABOUT US</a></li>
                            <li class="menu-item-has-children"><a href="#" title="" itemprop="url">CONTACT</a>
                                <ul>
                                    <li><a href="contact-us1.html" title="" itemprop="url">Contact Us Style 1</a></li>
                                    <li><a href="contact-us2.html" title="" itemprop="url">Contact Us Style 2</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <div class="header-search-wrap">
                        <a href="#" title="" itemprop="url"><i class="fa fa-search"></i> SEARCH</a>
                        <div class="header-search theme-bg">
                            <span class="search-close-btn"><i class="fa fa-close"></i></span>
                            <form>
                                <input type="text" placeholder="Search here...">
                            </form>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </header><!-- Header Style 1 -->
    <div class="res-header">
        <div class="res-header-top">
            <div class="res-top-links">
                <a href="#" title="" itemprop="url"><i class="fa fa-shopping-basket theme-clr"></i> Shop</a>
                <a href="#" title="" itemprop="url"><i class="fa fa-sign-in theme-clr"></i> Login</a>
                <a href="#" title="" itemprop="url"><i class="fa fa-user theme-clr"></i> Sign Up</a>
            </div>
            <div class="res-top-links2">
                <a class="theme-bg" href="become-volunteer.html" title="" itemprop="url">Become A Volunteer</a>
                <a class="blue-bg" href="donate-now.html" title="" itemprop="url">Donate Now</a>
            </div>
        </div>
        <div class="res-logo-sec">
            <div class="logo"><a href="index-2.html" title="" itemprop="url"><img src="{{asset('public/frontend/assets/images/logo2.png')}}" alt="logo2.png" itemprop="image"></a></div>
            <span class="res-menu-btn blue-bg brd-rd5"><i class="fa fa-align-justify"></i></span>
        </div>
        <div class="res-menu">
            <span class="res-menu-close brd-rd5"><i class="fa fa-close"></i></span>
            <ul>
                <li class="menu-item-has-children"><a href="#" title="" itemprop="url">HOME</a>
                    <ul>
                        <li><a href="index-2.html" title="" itemprop="url">Homepage 1</a></li>
                        <li><a href="index-rtl-arabic.html" title="" itemprop="url">Homepage  RTL (Arabic)</a></li>
                        <li><a href="index2.html" title="" itemprop="url">Homepage 3</a></li>
                        <li><a href="index2-boxed.html" title="" itemprop="url">Homepage Boxed</a></li>
                    </ul>
                </li>
                <li class="menu-item-has-children"><a href="#" title="" itemprop="url">BLOG</a>
                    <ul>
                        <li><a href="blog-grid.html" title="" itemprop="url">Blog Grid Style</a></li>
                        <li><a href="blog-unique.html" title="" itemprop="url">Blog Unique Grid Style</a></li>
                        <li><a href="blog-list.html" title="" itemprop="url">Blog List Style</a></li>
                        <li><a href="blog-detail.html" title="" itemprop="url">Blog Detail</a></li>
                    </ul>
                </li>
                <li class="menu-item-has-children"><a href="#" title="" itemprop="url">PAGES</a>
                    <ul>
                        <li class="menu-item-has-children"><a href="#" title="" itemprop="url">Priorities</a>
                            <ul>
                                <li><a href="priorities.html" title="" itemprop="url">Our Priorities</a></li>
                                <li><a href="priorities-detail.html" title="" itemprop="url">Priorities Detail</a></li>
                            </ul>
                        </li>
                        <li class="menu-item-has-children"><a href="#" title="" itemprop="url">Our Volunteers</a>
                            <ul>
                                <li><a href="volunteer.html" title="" itemprop="url">Our Volunteers</a></li>
                                <li><a href="volunteer-detail.html" title="" itemprop="url">Volunteers Detail</a></li>
                            </ul>
                        </li>
                        <li class="menu-item-has-children"><a href="#" title="" itemprop="url">Gallery</a>
                            <ul>
                                <li><a href="gallery1.html" title="" itemprop="url">Gallery Style 1</a></li>
                                <li><a href="gallery2.html" title="" itemprop="url">Gallery Style 2</a></li>
                                <li><a href="gallery3.html" title="" itemprop="url">Gallery Style 3</a></li>
                            </ul>
                        </li>
                        <li><a href="become-volunteer.html" title="" itemprop="url">Become A Volunteer</a></li>
                        <li><a href="donate-now.html" title="" itemprop="url">Donate Now</a></li>
                        <li><a href="mission-vission.html" title="" itemprop="url">Mission & Vission</a></li>
                        <li><a href="branches.html" title="" itemprop="url">Find Your Local Unit</a></li>
                        <li><a href="coming-soon.html" title="" itemprop="url">Coming Soon</a></li>
                        <li><a href="404.html" title="" itemprop="url">404 Error Page</a></li>
                    </ul>
                </li>
                <li class="menu-item-has-children"><a href="#" title="" itemprop="url">TAKE ACTION</a>
                    <ul>
                        <li><a href="causes-grid.html" title="" itemprop="url">Cause Grid Style</a></li>
                        <li><a href="causes-list.html" title="" itemprop="url">Cause List Style</a></li>
                        <li><a href="cause-detail.html" title="" itemprop="url">Cause Detail</a></li>
                    </ul>
                </li>
                <li class="menu-item-has-children"><a href="#" title="" itemprop="url">SHOP</a>
                    <ul>
                        <li><a href="products.html" title="" itemprop="url">Our Products</a></li>
                        <li><a href="product-detail.html" title="" itemprop="url">Product Detail</a></li>
                        <li><a href="product-cart.html" title="" itemprop="url">Product Cart</a></li>
                        <li><a href="checkout.html" title="" itemprop="url">Checkout</a></li>
                    </ul>
                </li>
                <li class="menu-item-has-children"><a href="#" title="" itemprop="url">OUR EVENTS</a>
                    <ul>
                        <li><a href="events-grid.html" title="" itemprop="url">Events Grid Style 1</a></li>
                        <li><a href="events-grid2.html" title="" itemprop="url">Events Grid Style 2</a></li>
                        <li><a href="events-list.html" title="" itemprop="url">Events List Style</a></li>
                        <li><a href="event-detail.html" title="" itemprop="url">Event Detail</a></li>
                    </ul>
                </li>
                <li><a href="about-us.html" title="" itemprop="url">ABOUT US</a></li>
                <li class="menu-item-has-children"><a href="#" title="" itemprop="url">CONTACT</a>
                    <ul>
                        <li><a href="contact-us1.html" title="" itemprop="url">Contact Us Style 1</a></li>
                        <li><a href="contact-us2.html" title="" itemprop="url">Contact Us Style 2</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div><!-- Responsive Header -->

    @yield('content')





    <footer>
        <div class="spacing theme-bg top-spac90 bottom-spac90">
            <div class="container">
                <div class="footer-wrap">
                    <div class="row">
                        <div class="col-md-3 col-sm-12 col-lg-3">
                            <div class="footer-about brd-rd5 blue-bg">
                                <div class="logo"><a href="index-2.html" title="" itemprop="url"><img src="{{asset('public/frontend/assets/images/logo.png')}}" alt="logo.png" itemprop="image"></a></div>
                                <p itemprop="description">Year after year, families tell us why they choose Hello Summer as a priority place for their kids to spend summer holidays at and to have the best time ever.</p>
                                <div class="social-btns">
                                    <span>Connect Online:</span>
                                    <a class="brd-rd50" data-toggle="tooltip" data-placement="top" href="#" title="Google Plus" itemprop="url" target="_blank"><i class="fa fa-google-plus"></i></a>
                                    <a class="brd-rd50" data-toggle="tooltip" data-placement="top" href="#" title="Twitter" itemprop="url" target="_blank"><i class="fa fa-twitter"></i></a>
                                    <a class="brd-rd50" data-toggle="tooltip" data-placement="top" href="#" title="Linkedin" itemprop="url" target="_blank"><i class="fa fa-linkedin"></i></a>
                                    <a class="brd-rd50" data-toggle="tooltip" data-placement="top" href="#" title="Facebook" itemprop="url" target="_blank"><i class="fa fa-facebook"></i></a>
                                </div>
                            </div><!-- Footer About -->
                        </div>
                        <div class="col-md-9 col-sm-12 col-lg-9">
                            <div class="remove-ext11">
                                <div class="row">
                                    <div class="col-md-3 col-sm-4 col-lg-3">
                                        <div class="widget-box">
                                            <h5 itemprop="headline">Take <span>Action</span></h5>
                                            <ul>
                                                <li><a href="donate-now.html" title="" itemprop="url">Contribute Now</a></li>
                                                <li><a href="volunteer.html" title="" itemprop="url">Our Volunteers</a></li>
                                                <li><a href="causes-grid.html" title="" itemprop="url">Action Center</a></li>
                                                <li><a class="register-vote-popup-btn" href="#" title="" itemprop="url">Register to Vote</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-4 col-lg-3">
                                        <div class="widget-box">
                                            <h5 itemprop="headline">Get <span>Involved</span></h5>
                                            <ul>
                                                <li><a href="blog-unique.html" title="" itemprop="url">Blog</a></li>
                                                <li><a href="priorities.html" title="" itemprop="url">Support Our Work</a></li>
                                                <li><a href="products.html" title="" itemprop="url">Our Products</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-4 col-lg-3">
                                        <div class="widget-box">
                                            <h5 itemprop="headline">Quick <span>Links</span></h5>
                                            <ul>
                                                <li><a href="blog-grid.html" title="" itemprop="url">News Releases</a></li>
                                                <li><a href="events-grid.html" title="" itemprop="url">Events</a></li>
                                                <li><a href="about-us.html" title="" itemprop="url">Terms of Use</a></li>
                                                <li><a href="contact-us2.html" title="" itemprop="url">Contact Us</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-4 col-lg-3">
                                        <div class="widget-box">
                                            <div class="flicker-gallery">
                                                <div class="flicker-inner">
                                                    <a class="brd-rd5" href="{{asset('public/frontend/assets/images/lg.png')}}" data-fancybox="gallery" title="" itemprop="url"><img src="assets/images/resources/flicker-img1.jpg" alt="flicker-img1.jpg" itemprop="image"></a>
                                                </div>
                                                <div class="flicker-inner">
                                                    <a class="brd-rd5" href="{{asset('public/frontend/assets/images/resources/flicker-img2.jpg')}}" data-fancybox="gallery" title="" itemprop="url"><img src="assets/images/resources/flicker-img2.jpg" alt="flicker-img2.jpg" itemprop="image"></a>
                                                </div>
                                                <div class="flicker-inner">
                                                    <a class="brd-rd5" href="{{asset('public/frontend/assets/images/resources/flicker-img3.jpg')}}" data-fancybox="gallery" title="" itemprop="url"><img src="assets/images/resources/flicker-img3.jpg" alt="flicker-img3.jpg" itemprop="image"></a>
                                                </div>
                                                <div class="flicker-inner">
                                                    <a class="brd-rd5" href="{{asset('public/frontend/assets/images/resources/flicker-img4.jpg')}}" data-fancybox="gallery" title="" itemprop="url"><img src="assets/images/resources/flicker-img4.jpg" alt="flicker-img4.jpg" itemprop="image"></a>
                                                </div>
                                                <div class="flicker-inner">
                                                    <a class="brd-rd5" href="{{asset('public/frontend/assets/images/resources/flicker-img5.jpg')}}" data-fancybox="gallery" title="" itemprop="url"><img src="assets/images/resources/flicker-img5.jpg" alt="flicker-img5.jpg" itemprop="image"></a>
                                                </div>
                                                <div class="flicker-inner">
                                                    <a class="brd-rd5" href="{{asset('public/frontend/assets/images/resources/flicker-img6.jpg')}}" data-fancybox="gallery" title="" itemprop="url"><img src="assets/images/resources/flicker-img6.jpg" alt="flicker-img6.jpg" itemprop="image"></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="newsletter-wrap2">
                                <h4 itemprop="headline"><span>STAY</span> INFORMED</h4>
                                <form class="newsletter-form2">
                                    <input class="brd-rd40" type="email" placeholder="Please Enter Your Email Id">
                                    <button type="submit"><i class="fa fa-arrow-right"></i></button>
                                </form>
                                <div class="facts-wrap2">
                                    <div class="fact-box2">
                                        <span class="theme-clr">Total Voters</span>
                                        <h4 itemprop="headline"><span class="counter">28179</span></h4>
                                    </div>
                                    <div class="fact-box2">
                                        <span class="theme-clr">Campaigns</span>
                                        <h4 itemprop="headline"><span class="counter">20</span><small>K</small></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- Footer Wrap -->
            </div>
        </div>
    </footer><!-- Footer -->
    <div class="bottom-bar">
        <div class="container">
            <div class="footer-wrap">
                <p itemprop="description"><a class="theme-clr" href="http://html.wordpresspie.com/country" title="Country - Political HTML5 Template" itemprop="url" target="_blank">ImprovingIndia</a> &copy; 2018, All Rights Reserved, Design & Developed By: <a class="theme-clr" href="https://ithubbegin.com" title="" itemprop="url" target="_blank">Ithubbegin</a></p>
                <ul class="bottom-links">
                    <li><a href="index-2.html" title="" itemprop="url">HOME</a></li>
                    <li><a href="events-grid.html" title="" itemprop="url">EVENTS</a></li>
                    <li><a href="blog-grid.html" title="" itemprop="url">NEWS</a></li>
                    <li><a href="contact-us1.html" title="" itemprop="url">CONTACT</a></li>
                </ul>
            </div>
        </div>
    </div><!-- Bottom bar -->

    <div class="register-vote-popup-wrapper text-center">
        <span class="popup-close"><i class="fa fa-close"></i></span>
        <div class="register-vote-popup">
            <div class="register-vote-popup-title theme-bg"><h4 itemprop="headline">Register For Vote</h4></div>
            <div class="register-vote-popup-form-wrap">
                <form>
                    <div class="row mrg10">
                        <div class="col-md-12 col-sm-12 col-lg-12">
                            <div class="input-field">
                                <input class="brd-rd33" type="text" placeholder="First Name">
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-lg-12">
                            <div class="input-field">
                                <input class="brd-rd33" type="text" placeholder="Last Name">
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-lg-12">
                            <div class="input-field">
                                <input class="brd-rd33" type="email" placeholder="Email Address">
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-lg-12">
                            <div class="input-field">
                                <input class="brd-rd33" type="text" placeholder="Phone No">
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12 col-lg-4">
                            <div class="input-field">
                                <input class="brd-rd33" type="text" placeholder="Day">
                                <i class="fa fa-calendar-o"></i>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12 col-lg-4">
                            <div class="input-field">
                                <input class="brd-rd33" type="text" placeholder="Month">
                                <i class="fa fa-calendar-o"></i>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12 col-lg-4">
                            <div class="input-field">
                                <input class="brd-rd33" type="text" placeholder="Year">
                                <i class="fa fa-calendar-o"></i>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-lg-12">
                            <div class="input-field">
                                <input class="brd-rd33" type="text" placeholder="CNIC No ( xxxxx - xxxxxxx - x )">
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-lg-12">
                            <button class="brd-rd33 theme-btn2 big" type="submit">REGISTER NOW</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div><!-- Register Vote Popup Wrapper -->

    {{--temp Reg--}}

    <div class="register-vote-popup-wrapper1 text-center">
        <span class="popup-close"><i class="fa fa-close"></i></span>
        <div class="register-vote-popup1">
            <div class="register-vote-popup-title theme-bg"><h4 itemprop="headline">Show Interest</h4></div>
            <div class="register-vote-popup-form-wrap">
                <form>
                    <div class="row mrg10">
                        <div class="col-md-12 col-sm-12 col-lg-12">
                            <div class="input-field">
                                <input class="brd-rd33" type="text" placeholder="First Name">
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-lg-12">
                            <div class="input-field">
                                <input class="brd-rd33" type="text" placeholder="Last Name">
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-lg-12">
                            <div class="input-field">
                                <input class="brd-rd33" type="email" placeholder="Email Address">
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-lg-12">
                            <div class="input-field">
                                <input class="brd-rd33" type="text" placeholder="Phone No">
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12 col-lg-4">
                            <div class="input-field">
                                <input class="brd-rd33" type="text" placeholder="Day">
                                <i class="fa fa-calendar-o"></i>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12 col-lg-4">
                            <div class="input-field">
                                <input class="brd-rd33" type="text" placeholder="Month">
                                <i class="fa fa-calendar-o"></i>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12 col-lg-4">
                            <div class="input-field">
                                <input class="brd-rd33" type="text" placeholder="Year">
                                <i class="fa fa-calendar-o"></i>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-lg-12">
                            <div class="input-field">
                                <input class="brd-rd33" type="text" placeholder="CNIC No ( xxxxx - xxxxxxx - x )">
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-lg-12">
                            <button class="brd-rd33 theme-btn2 big" type="submit">REGISTER NOW</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div><!-- Register Vote Popup Wrapper -->
</main><!-- Project Main Wrapper -->


<script src="{{asset('public/frontend/assets/js/jquery.min.js')}}"></script>
<script src="{{asset('public/frontend/assets/js/bootstrap.min.js')}}"></script>
<script src="{{asset('public/frontend/assets/js/plugins.js')}}"></script>
<script src="{{asset('public/frontend/assets/js/custom-scripts.js')}}"></script>

<script src="{{asset('public/frontend/assets/js/revolution/jquery.themepunch.tools.min.js')}}"></script>
<script src="{{asset('public/frontend/assets/js/revolution/jquery.themepunch.revolution.min.js')}}"></script>

<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->
<script src="{{asset('public/frontend/assets/js/revolution/extensions/revolution.extension.actions.min.js')}}"></script>
<script src="{{asset('public/frontend/assets/js/revolution/extensions/revolution.extension.carousel.min.js')}}"></script>
<script src="{{asset('public/frontend/assets/js/revolution/extensions/revolution.extension.kenburn.min.js')}}"></script>
<script src="{{asset('public/frontend/assets/js/revolution/extensions/revolution.extension.layeranimation.min.js')}}"></script>
<script src="{{asset('public/frontend/assets/js/revolution/extensions/revolution.extension.migration.min.js')}}"></script>
<script src="{{asset('public/frontend/assets/js/revolution/extensions/revolution.extension.navigation.min.js')}}"></script>
<script src="{{asset('public/frontend/assets/js/revolution/extensions/revolution.extension.parallax.min.js')}}"></script>
<script src="{{asset('public/frontend/assets/js/revolution/extensions/revolution.extension.slideanims.min.js')}}"></script>
<script src="{{asset('public/frontend/assets/js/revolution/extensions/revolution.extension.video.min.js')}}"></script>
<script src="{{asset('public/frontend/assets/js/revolution/revolution-init.js')}}"></script>
</body>


</html>