<script src="<?php echo e(asset('public/backend/vendors/jquery/dist/jquery.min.js')); ?>"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo e(asset('public/backend/vendors/popper.js/dist/umd/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/backend/vendors/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>

<!-- Slimscroll JavaScript -->
<script src="<?php echo e(asset('public/backend/dist/js/jquery.slimscroll.js')); ?>"></script>

<!-- Fancy Dropdown JS -->
<script src="<?php echo e(asset('public/backend/dist/js/dropdown-bootstrap-extended.js')); ?>"></script>

<!-- FeatherIcons JavaScript -->
<script src="<?php echo e(asset('public/backend/dist/js/feather.min.js')); ?>"></script>

<!-- Toggles JavaScript -->
<script src="<?php echo e(asset('public/backend/vendors/jquery-toggles/toggles.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/backend/dist/js/toggle-data.js')); ?>"></script>

<!-- Counter Animation JavaScript -->
<script src="<?php echo e(asset('public/backend/vendors/waypoints/lib/jquery.waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/backend/vendors/jquery.counterup/jquery.counterup.min.js')); ?>"></script>

<!-- EChartJS JavaScript -->
<script src="<?php echo e(asset('public/backend/vendors/echarts/dist/echarts-en.min.js')); ?>"></script>

<!-- Sparkline JavaScript -->
<script src="vendors/jquery.sparkline/dist/jquery.sparkline.min.js"></script>

<!-- Vector Maps JavaScript -->
<script src="<?php echo e(asset('public/backend/vendors/vectormap/jquery-jvectormap-2.0.3.min.js')); ?>"></script>
<script src="<?php echo e(asset('public/backend/vendors/vectormap/jquery-jvectormap-world-mill-en.js')); ?>"></script>
<script src="<?php echo e(asset('public/backend/dist/js/vectormap-data.js')); ?>"></script>

<!-- Owl JavaScript -->
<script src="<?php echo e(asset('public/backend/vendors/owl.carousel/dist/owl.carousel.min.js')); ?>"></script>

<!-- Toastr JS -->
<script src="<?php echo e(asset('public/backend/vendors/jquery-toast-plugin/dist/jquery.toast.min.js')); ?>"></script>

<!-- Init JavaScript -->
<script src="<?php echo e(asset('public/backend/dist/js/init.js')); ?>"></script>
<script src="<?php echo e(asset('public/backend/dist/js/dashboard-data.js')); ?>"></script>