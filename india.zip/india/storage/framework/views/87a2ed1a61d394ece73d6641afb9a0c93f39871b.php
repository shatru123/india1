<head>

<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<title>Pangong I CRM Dashboard</title>
<meta name="description" content="A responsive bootstrap 4 admin dashboard template by hencework" />

<!-- Favicon -->
<link rel="shortcut icon" href="favicon.ico">
<link rel="icon" href="favicon.ico" type="image/x-icon">

<!-- vector map CSS -->
<link href="<?php echo e(asset('public/backend/vendors/vectormap/jquery-jvectormap-2.0.3.css')); ?>" rel="stylesheet" type="text/css" />

<!-- Toggles CSS -->
<link href="<?php echo e(asset('public/backend/vendors/jquery-toggles/css/toggles.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('public/backend/vendors/jquery-toggles/css/themes/toggles-light.css')); ?>" rel="stylesheet" type="text/css">

<!-- Toastr CSS -->
<link href="<?php echo e(asset('public/backend/vendors/jquery-toast-plugin/dist/jquery.toast.min.css')); ?>" rel="stylesheet" type="text/css">

<!-- Custom CSS -->
<link href="<?php echo e(asset('public/backend/dist/css/style.css')); ?>" rel="stylesheet" type="text/css">
</head>